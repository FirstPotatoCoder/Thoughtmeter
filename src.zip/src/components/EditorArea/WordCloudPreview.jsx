import { useEffect, useRef, useState } from "react";
import "./WordCloudPreview.css";

const BLUE = ["#6B7AE6", "#5E60CE", "#8791E8"];
const CORAL = ["#E8695F", "#EE7D74"];

const pickColor = (c, i) =>
  (c === "b" ? BLUE : CORAL)[i % (c === "b" ? BLUE.length : CORAL.length)];

// Each word: text, size (px), colour family (b|r) and a rough anchor (% of the
// cloud box). Reveal order is the array order — it grows from the big central
// words outward. After every reveal a couple of existing words are nudged so the
// whole cloud feels alive, and once full it keeps breathing while hovered.
const POOL = [
  { text: "creative", size: 72, c: "b", x: 50, y: 50 },
  { text: "fast", size: 56, c: "b", x: 43, y: 30 },
  { text: "leader", size: 56, c: "r", x: 54, y: 63 },
  { text: "quality", size: 54, c: "r", x: 69, y: 55 },
  { text: "bold", size: 40, c: "r", x: 36, y: 47 },
  { text: "focus", size: 40, c: "b", x: 66, y: 37 },
  { text: "sharing", size: 40, c: "b", x: 41, y: 70 },
  { text: "inspire", size: 40, c: "b", x: 26, y: 34 },
  { text: "leadership", size: 40, c: "b", x: 28, y: 55 },
  { text: "transpiration", size: 40, c: "r", x: 53, y: 73 },
  { text: "integration", size: 40, c: "r", x: 53, y: 87 },
  { text: "leading", size: 40, c: "b", x: 74, y: 71 },
  { text: "top", size: 30, c: "r", x: 56, y: 15 },
  { text: "inspirational", size: 30, c: "b", x: 70, y: 20 },
  { text: "quick", size: 30, c: "r", x: 81, y: 43 },
  { text: "innovation", size: 22, c: "r", x: 23, y: 42 },
  { text: "performance", size: 22, c: "r", x: 87, y: 33 },
  { text: "inspiration", size: 22, c: "b", x: 84, y: 55 },
  { text: "change", size: 22, c: "b", x: 38, y: 59 },
  { text: "transformers", size: 22, c: "r", x: 87, y: 62 },
  { text: "innovative", size: 22, c: "b", x: 83, y: 70 },
];

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

export default function WordCloudPreview() {
  // Start with just the hero word ("creative"), matching the reference's first
  // frame; the rest pop in one at a time.
  const [words, setWords] = useState(() =>
    POOL.slice(0, 1).map((w, i) => ({
      id: i,
      text: w.text,
      size: w.size,
      color: pickColor(w.c, i),
      x: w.x,
      y: w.y,
      jx: 0,
      jy: 0,
    })),
  );
  const nextRef = useRef(1);

  useEffect(() => {
    let timer;

    // Nudge 1-2 already-present words a little so the layout feels alive.
    const jitter = (count) =>
      setWords((prev) => {
        const picked = new Set();
        while (picked.size < Math.min(count, prev.length)) {
          picked.add(Math.floor(Math.random() * prev.length));
        }
        return prev.map((w, i) =>
          picked.has(i)
            ? {
                ...w,
                jx: clamp(w.jx + (Math.random() * 12 - 6), -16, 16),
                jy: clamp(w.jy + (Math.random() * 10 - 5), -12, 12),
              }
            : w,
        );
      });

    const step = () => {
      const i = nextRef.current;
      if (i < POOL.length) {
        const w = POOL[i];
        nextRef.current = i + 1;
        setWords((prev) => [
          ...prev,
          {
            id: i,
            text: w.text,
            size: w.size,
            color: pickColor(w.c, i),
            x: w.x,
            y: w.y,
            jx: 0,
            jy: 0,
          },
        ]);
        // A new word lands -> shift one (sometimes two) of the old ones.
        jitter(1 + (Math.random() < 0.4 ? 1 : 0));
        timer = setTimeout(step, 300 + Math.random() * 260);
      } else {
        // Cloud is full: keep it gently breathing while hovered.
        timer = setTimeout(() => {
          jitter(1 + (Math.random() < 0.4 ? 1 : 0));
          step();
        }, 1300 + Math.random() * 900);
      }
    };

    timer = setTimeout(step, 250);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="wc-preview">
      {words.map((w) => (
        <span
          key={w.id}
          className="wc-word"
          style={{
            left: `${w.x}%`,
            top: `${w.y}%`,
            fontSize: w.size,
            color: w.color,
            // Center the word on its anchor, then apply the (animated) jitter.
            transform: `translate(calc(-50% + ${w.jx}px), calc(-50% + ${w.jy}px))`,
          }}
        >
          <span className="wc-word-pop">{w.text}</span>
        </span>
      ))}
    </div>
  );
}
